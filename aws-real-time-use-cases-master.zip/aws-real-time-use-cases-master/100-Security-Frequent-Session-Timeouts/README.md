# AWS Role Session TimeOuts

## 🔥 Scenario

Your client has multiple AWS accounts and have cross account access role to switch between the accounts. After switch from one aws account to other aws account role, the session was getting disconnected frequently, disrupting developer productivity.

You clients wants you to increase the session duration. Can you help them with the steps?

## 📋 Next Steps

1. What actions will you take?
1. How will you test your solution?
1. Can you automate its deployment and improve its re-usability as a bonus feature?

## 🎯Solution[s]

Does this [article][1] help.

## 👋 Buy me a coffee

Buy me a coffee ☕ through [Paypal](https://paypal.me/valaxy), _or_ You can reach out to get more details through [here](https://youtube.com/c/valaxytechnologies/about).

### ℹ️ Metadata

**Level**: 300

[1]: https://aws.amazon.com/about-aws/whats-new/2018/03/longer-role-sessions
