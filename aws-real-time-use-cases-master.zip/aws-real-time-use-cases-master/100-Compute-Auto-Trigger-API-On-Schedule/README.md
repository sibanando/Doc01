# Automatically Trigger APIGW/Lambda Function on Schedule

## 🔥 Scenario

Your clients wants to trigger an lambda function published behind an API GW at a prescheduled time. The API receives a json payload to successfully trigger the lambda function. How can you achieve it?

## 📋 Next Steps

1. What actions will you take to ?
1. What order will you take those actions?

## 👋 Buy me a coffee

Buy me a coffee ☕ through [Paypal](https://paypal.me/valaxy), _or_ You can reach out to get more details through [here](https://youtube.com/c/valaxytechnologies/about).

### ℹ️ Metadata

**Level**: 100
