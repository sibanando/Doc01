# S3 Pre-Signed Objects

## 🔥 Scenario

Your customer wants your create pre-signed URL's for all objects in a particular S3 bucket. How do you propose to achieve this?

## 👋 Buy me a coffee

Buy me a coffee ☕ through [Paypal](https://paypal.me/valaxy), _or_ You can reach out to get more details through [here](https://youtube.com/c/valaxytechnologies/about).

### ℹ️ Metadata

**Level**: 100
